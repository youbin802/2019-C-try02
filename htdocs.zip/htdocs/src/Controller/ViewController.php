<?php

namespace src\Controller;
use src\App\DB;
class ViewController extends Controller {
    public function index() {
        return $this->view('index');
    }
    public function login() {
        if(user()) {
            error();
        }
        return $this->view('login');
    }
    public function join() {
        if(user()) {
            error();
        }
        return $this->view('join');
    }
    public function admin() {
        if(!user()) {
            error('user');
        }
        $menus = DB::fetchAll('select * from menu where user_idx=?',[user()->idx]);
        $boards = DB::fetchAll('select * from board where user_idx=?',[user()->idx]);
        $users = DB::fetchAll('select * from user');
        return $this->view('admin',['users'=>$users, 'boards'=>$boards,'menus'=>$menus]);
    }
    public function myblog() {
        if(!user()) {
            error('user');
        } else {
            if(user()->email == 'admin') {
                go('/','관리자 게시판 없음');
            }else {
                header('location: /' . user()->email);
            }
        }
    }
    public function blog($email="") {
        $user = DB::fetch('select * from user where email=?',[$email]);
        return $this->view('blog',['title'=>'blog','user'=>$user,'menus'=>$this->getMenus($user->idx)]);
    }
    public function menu($menu_idx =0 ) {
        $menu = DB::fetch('select * from menu where idx=?',[$menu_idx]);
        $user = DB::fetch('select * from user where idx=?',[$menu->user_idx]);
        return $this->view('blog',['title'=>'blog','user'=>$user,'menus'=>$this->getMenus($user->idx),'menu'=>$menu,'contents'=>$this->getContents($menu->board_idx)]);
    }
    public function write($menu_idx =0 ) {
        $menu = DB::fetch('select * from menu where idx=?',[$menu_idx]);
        $user = DB::fetch('select * from user where idx=?',[$menu->user_idx]);
        return $this->view('write',['title'=>'blog','user'=>$user,'menus'=>$this->getMenus($user->idx),'menu'=>$menu]);
    }
    public function content($content_idx =0 ) {
        $content = DB::fetch('select * from content where idx=?',[$content_idx]);
        $menu = DB::fetch('select * from menu where board_idx=?',[$content->board_idx]);
        $user = DB::fetch('select * from user where idx=?',[$menu->user_idx]);

        $content-> user = DB::fetch('select * from user where idx=?',[$content->writer_idx]);
        $comments = DB::fetchAll('select * from comment where content_idx =?',[$content_idx]);
        foreach($comments as $c) {
            $c->user = DB::fetch('select * from user where idx=?',[$c->user_idx]);
        }
        return $this->view('view',['title'=>'blog','user'=>$user,'menus'=>$this->getMenus($user->idx),'menu'=>$menu,'content'=>$content,'comments'=>$comments]);
    }
    public function reply($menu_idx =0 ) {
        $menu = DB::fetch('select * from menu where idx=?',[$menu_idx]);
        $user = DB::fetch('select * from user where idx=?',[$menu->user_idx]);
        return $this->view('reply',['title'=>'blog','user'=>$user,'menus'=>$this->getMenus($user->idx),'menu'=>$menu]);
    }
    public function update($content_idx =0 ) {
        $content = DB::fetch('select * from content where idx=?',[$content_idx]);
        $menu = DB::fetch('select * from menu where board_idx=?',[$content->board_idx]);
        $user = DB::fetch('select * from user where idx=?',[$menu->user_idx]);
        return $this->view('update',['title'=>'blog','user'=>$user,'menus'=>$this->getMenus($user->idx),'menu'=>$menu,'content'=>$content]);
    }
}